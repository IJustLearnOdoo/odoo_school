# Hospital Management Module

This module helps in managing doctors, patients, diseases, and patient visits in a hospital.

