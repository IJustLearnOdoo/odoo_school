from . import hr_hospital_person
from . import hr_hospital_disease
from . import hr_hospital_doctor
from . import hr_hospital_patient
from . import hr_hospital_visit
from . import hr_hospital_diagnosis
